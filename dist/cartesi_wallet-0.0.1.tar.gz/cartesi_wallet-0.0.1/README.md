# Python DApp Template

This is a template for Python Cartesi DApps wallet. It uses python3 to execute the backend application.
The application entrypoint is the `dapp.py` file.
